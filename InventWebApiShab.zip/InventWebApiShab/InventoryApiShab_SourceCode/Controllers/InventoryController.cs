﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using InventoryApiShab.Models;

namespace InventoryApiShab.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    public class InventoryController : ControllerBase
    {
        private readonly InventoryContext _context;

        public InventoryController(InventoryContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("[action]")]
        [Route("api/Inventory/Get")]
        public async Task<ActionResult<IEnumerable<Inventory>>> Get()
        {
            try
            {
                var products = _context.Inventory.AsQueryable();
                return await products.ToListAsync();
            }
            catch
            {
                return NotFound();
            }
        }

        // GET: api/Products/5
        [HttpGet]
        [Route("[action]")]
        [Route("api/Inventory/Get/{id}")]
        public async Task<ActionResult<Inventory>> Get(int id)
        {
            try
            {
                var products = await _context.Inventory.FindAsync(id);

                if (products == null)
                {
                    return NotFound();
                }

                return products;
            }
            catch
            {
                return NotFound();
            }
        }

        [HttpPost]
        [Route("[action]")]
        [Route("api/Inventory/Create")]
        public async Task<ActionResult<Inventory>> Post(Inventory inventory)
        {
            _context.Inventory.Add(inventory);
            await _context.SaveChangesAsync();

            return CreatedAtAction("Get", new { id = inventory.Id }, inventory);
        }

        [HttpPost]
        [Route("[action]")]
        [Route("api/Inventory/Update")]
        public async Task<IActionResult> Put(int id, Inventory inventory)
        {
            if (id != inventory.Id)
            {
                return BadRequest();
            }

            _context.Entry(inventory).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }



        [HttpDelete]
        [Route("[action]")]
        [Route("api/Inventory/Delete/{id}")]
        public async Task<ActionResult<Inventory>> DeleteProducts(int id)
        {
            try
            {
                var products = await _context.Inventory.FindAsync(id);
                if (products == null)
                {
                    return NotFound();
                }

                _context.Inventory.Remove(products);
                await _context.SaveChangesAsync();

                return products;
            }
            catch
            {
                return NotFound();
            }
        }

        private bool ProductsExists(int id)
        {
            return _context.Inventory.Any(e => e.Id == id);
        }
    }
}
